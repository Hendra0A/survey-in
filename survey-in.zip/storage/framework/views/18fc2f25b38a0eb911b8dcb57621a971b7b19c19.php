
<?php $__env->startSection('content'); ?>
<div class="content">   
    <div class="container">
      <div class="admin-hl-andro d-flex align-items-center mt-4 ms-3 mb-3">
        <?php if(auth()->user()->avatar): ?>
        <img src="<?php echo e(asset('storage/'.auth()->user()->avatar)); ?>" alt="" class=" rounded-circle ms-2" style="width: 4em; height: 4em; object-fit: cover;">
          <?php else: ?>
          <img src="/img/profile.png" alt="" class=" rounded-circle ms-2" style="width: 4em; height: 4em; object-fit: cover;">
          <?php endif; ?>
          <h6 class=" d-flex align-items-center m-0 ms-2" style="font-size: clamp(1rem, 2.5vw, 1.2rem);">Halo, <?php echo e(auth()->user()->nama_lengkap); ?> <img src="/img/hello.png" alt="" style="width: 1.5em;" class=" ms-1"> </h6>
      </div>
      <div class="row justify-content-center">
        <div class="col-12 ">
          <div class="d-flex ms-2 me-2 mt-2 m-auto justify-content-center shadow-sm bg-white p-3 justify-content-md-between" style="border-radius: 1em;">
              <div class="pe-1 d-flex flex-column justify-content-center">
                  <h4>Ayo selesaikan target surveimu!</h4>
                  <p class="mb-2">Kecamatan <?php echo e($data['kecamatan']['nama']); ?></p>
                  <p class=" text-primary mb-2">Status : <?php echo e($data['selesai']); ?>/<?php echo e($data['target']); ?> Survei</p>
                  <p class=" text-danger">Deadline :  <?php echo e($data['tanggal_selesai']); ?></p>
              </div>
              <div class="hero-beranda">
                  <img src="/img/beranda-hero.png" style="width: 7em;">
              </div>
          </div>
        </div>
      </div>
      <div class="ms-2 me-2 mt-2 m-auto justify-content-center" style="background: #F3F8FF;">
        <a href="/surveyor/riwayat-survei" class="text-end text-decoration-none fs-6 d-block">Riwayat Survei</a>
      </div>
      <div class="pilih-kec mt-4 mb-2 p-2">
          <label for="" class=" ms-4" id="pilih-kec">Kecamatan :</label>
          <select id="kecamatan" class="form-select form-select-sm m-auto shadow-none border-primary mt-1" style="width: 92%;" aria-label=".form-select-sm example">
              <?php $__currentLoopData = $area_survei->kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                  <option value="<?php echo e($kecamatan->id); ?>" <?php echo e(($data['kecamatan_id']==$kecamatan->id)?'selected' : ''); ?>><?php echo e($kecamatan->nama); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
      </div>
      <div class="row justify-content-evenly mt-5 mb-4">
        <div class="col-6 col-md-4">
          <div class="kartu satu p-1" style=" background: #6E86B4;">
            <div class="kartu-hero d-flex justify-content-center align-items-center ">
              <img src="/img/kartu-satu.png" alt="" style="width: 28%;">
              <p class="m-0 ms-2" id="jmlGang">-</p>
            </div>
            <h6 class=" m-0 mb-1">Gang dan Perumahan</h6>
            <p class="mb-0">di Kecamatan <span class="text-kec"><?php echo e($data['kecamatan']['nama']); ?></span></p>
          </div>
        </div>
        <div class="col-6 col-md-4">
          <div class="kartu dua p-1" style=" background: #849C95;">
            <div class="kartu-hero d-flex justify-content-center align-items-center pt-1">
              <img src="/img/kartu-dua.png" alt="" style="width: 30%;">
              <p class="m-0 ms-2" id="jlnBaik">-</p>
            </div>
            <h6 class=" m-0 mb-1 mt-1">Kondisi Jalan Baik</h6>
            <p class="mb-0">di Kecamatan <span class="text-kec"><?php echo e($data['kecamatan']['nama']); ?></span></p>
          </div>
        </div>
        <div class="col-6 col-md-4">
          <div class="kartu tiga p-1" style=" background: #EB7A7A;">
            <div class="kartu-hero d-flex justify-content-center align-items-center pt-1">
              <img src="/img/kartu-tiga.png" alt="" style="width: 30%;">
              <p class="m-0 ms-2" id="jlnJelek">-</p>
            </div>
            <h6 class=" m-0 mb-1 mt-1">Kondisi Jalan Tidak Baik</h6>
            <p class="mb-0">di Kecamatan <span class="text-kec"><?php echo e($data['kecamatan']['nama']); ?></span></p>
          </div>
        </div>
        <div class="col-6 col-md-4">
          <div class="kartu empat p-1" style=" background: #648360;">
            <div class="kartu-hero d-flex justify-content-center align-items-center">
              <img src="/img/kartu-empat.png" alt="" style="width: 27%;">
              <p class="m-0 ms-2" id="jmlRumah">-</p>
            </div>
            <h6 class=" m-0 mb-1 mt-2">Jumlah Rumah</h6>
            <p class="mb-0">di Kecamatan <span class="text-kec"><?php echo e($data['kecamatan']['nama']); ?></span></p>
          </div>
        </div>
        <div class="col-6 col-md-4 ">
          <div class="kartu lima p-1" style=" background: #9E82A8;">
            <div class="kartu-hero d-flex justify-content-center align-items-center ps-1">
              <img src="/img/kartu-lima.png" alt="" style="width: 30%;">
              <p class="m-0 ms-2 text-wrap" id="pnjJalan">-</p>
            </div>
            <h6 class="m-0 mb-1 mt-1">Panjang Jalan Perumahan</h6>
            <p class="mb-0">di Kecamatan <span class="text-kec"><?php echo e($data['kecamatan']['nama']); ?></span></p>
          </div>
        </div>
        <div class="col-6 col-md-4">
          <div class="kartu enam p-1" style=" background: #9AA55C;">
            <div class="kartu-hero d-flex justify-content-center align-items-center ps-1">
              <img src="/img/kartu-enam.png" alt="" style="width: 30%;">
              <p class="m-0 ms-2 text-wrap" id="lbrJalan">-</p>
            </div>
            <h6 class=" m-0 mb-1 mt-1">Lebar Jalan Perumahan</h6>
            <p class="mb-0">di Kecamatan <span class="text-kec"><?php echo e($data['kecamatan']['nama']); ?></span></p>
          </div>
        </div>
      </div>
    </div>
    <script src="/js/beranda-user.js"></script>
</div>
<?php echo $__env->make('user.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\survey-in\resources\views/user/index.blade.php ENDPATH**/ ?>