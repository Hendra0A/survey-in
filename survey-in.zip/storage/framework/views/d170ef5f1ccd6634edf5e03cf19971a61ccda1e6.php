
<?php $__env->startSection('header'); ?>
  <a href="/surveyor/beranda" class="nav-link"><i class="fas fa-chevron-left text-dark"></i></a>
  <span class="fw-bold">Riwayat Survei</span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container">
      <div class="Riwayat Survei m-3 ">
        <!-- Riwayat Survei -->
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card-riwayat-survei p-3 mb-3 justify-content-center rounded-3 shadow-sm bg-white">
            <p class="mb-2"><?php echo e($item->tanggal_mulai); ?> - <?php echo e($item->tanggal_selesai); ?></p>
            <h4 class="mb-0">Kecamatan <?php echo e($item->kecamatan->nama); ?></h4>
            <hr>
            <p class="mb-2">Kategori Target : perminggu</p>
            <p class="mb-2">Status : <?php echo e($item->selesai); ?> dari <?php echo e($item->target); ?> Gang dan perumahan</p>
            <p class="mb-2">Perhitungan target : <span class="<?php echo e(( $item->selesai - $item->target < 0)? 'text-danger':'text-success'); ?> fw-bold">
            <?php if(($item->selesai - $item->target) > 0): ?>
                + <?php echo e($item->selesai - $item->target); ?> Gang dan Perumahan
            <?php elseif($item->selesai - $item->target == 0): ?>
                Survei Sukses
            <?php elseif(($item->selesai - $item->target) < 0): ?>
                <?php echo e($item->selesai - $item->target); ?> Gang dan Perumahan
            <?php endif; ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\survey-in\resources\views\user\riwayat-survei.blade.php ENDPATH**/ ?>