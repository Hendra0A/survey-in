
<?php $__env->startSection('title','Profile'); ?>
<?php $__env->startSection('main-content'); ?>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content d-flex flex-column ms-sm-1 ps-sm-1 ms-0 ps-0" id="prf-page-content">
        <div class="admin-hl mt-4">
            <h1>Profil Admin</h1>
            <p>Profil Admin berisi data pribadi Admin.</p>
            <div class="admin d-flex">
                <?php if(auth()->user()->avatar): ?>
                <img src="<?php echo e(asset('storage/' . auth()->user()->avatar)); ?>" alt="aw" class="hl-img rounded-circle">
                  <?php else: ?>
                  <img src="/img/profile.png" alt="" class="hl-img rounded-circle">
                  <?php endif; ?>
                <div class="hl-status ms-4 d-flex flex-column justify-content-center">
                    <h3><?php echo e($data->nama_lengkap); ?></h3>
                    <p><?php echo e($data->role); ?></p>
                </div>
            </div>
        </div>
        <div class="biodata mt-5 m-auto">
            <table class="bio m-auto" style="width: 90%;">
                <tr>
                    <td class="left-bio p-2" style="vertical-align: top;">Nama Lengkap</td>
                    
                    <td class="right-bio p-2">: <?php echo e($data->nama_lengkap); ?></td>
                </tr>
                <tr>
                    <td class="left-bio p-2" style="vertical-align: top;">Email</td>
                    
                    <td class="right-bio p-2">: <?php echo e($data->email); ?></td>
                </tr>
                <tr>
                    <td class="left-bio p-2" style="vertical-align: top;">Tanggal Lahir</td>
                    
                <td class="right-bio p-2">: <?php echo e(\Carbon\Carbon::parse($data->tanggal_lahir)->format('j F Y')); ?></td>
                </tr>
                <tr>
                    <td class="left-bio p-2" style="vertical-align: top;">Jenis Kelamin</td>
                    
                    <td class="right-bio p-2">: <?php echo e($data->gender); ?></td>
                </tr>
                <tr>
                    <td class="left-bio p-2" style="vertical-align: top;">No. Handphone</td>
                    
                    <td class="right-bio p-2">: <?php echo e($data->nomor_telepon); ?></td>
                </tr>
                <tr style="border: none;">
                    <td class="left-bio p-2" style="vertical-align: top;">Alamat</td>
                    
                    <td class="right-bio p-2">: <?php echo e($data->alamat); ?></td>
                </tr>
            </table>
        </div>
        <div class="submit d-flex justify-content-center mt-5">
            <a href="/profile/edit-profile/admin" class="text-light text-decoration-none btn btn-lg btn-primary active mb-5 shadow-none h-auto border-0" id="submit">Edit profil</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\survey-in\resources\views/admin/profile.blade.php ENDPATH**/ ?>