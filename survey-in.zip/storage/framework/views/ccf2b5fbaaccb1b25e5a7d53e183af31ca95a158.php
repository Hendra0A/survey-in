
<?php $__env->startSection('header'); ?>
    <a href="/surveyor/data-survei" class="nav-link"><i class="fas fa-chevron-left text-dark"></i></a>
    <span class="fw-bold">Detail Data Survei Gang <?php echo e($data->nama_gang); ?></span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container">
            
            <h6 class="detail col-12 text-center mt-3 mb-4">DATA PRASARANA UTILITAS GANG DAN PERUMAHAN<br>
                (<?php echo e($data->kecamatan->nama); ?>)</h6>
            <div class="detail-data col-12 d-flex flex-column justify-content-center">
                <table class="detail col-12 mb-3">
                    <tr>
                        <th>Nama gang dan perumahan</th>
                        <td>: <?php echo e($data->nama_gang); ?></td>
                    </tr>

                    <tr>
                        <th>Lokasi</th>
                        <td>: <?php echo e($data->lokasi); ?></td>
                    </tr>

                    <tr>
                        <th>Koordinat</th>
                        <td>: <?php echo e($data->no_gps); ?></td>
                    </tr>

                    <tr>
                        <th>Dimensi jalan utama</th>
                        <td>
                            : Panjang = <?php echo e($data->dimensi_jalan_panjang); ?>m <br>
                            : Lebar = <?php echo e($data->dimensi_jalan_lebar); ?>m
                        </td>
                    </tr>

                    <tr>
                        <th>Kondisi jalan</th>
                        <td>: <?php echo e($data->konstruksiJalan->jenis); ?> Kondisi <?php echo e($data->status_jalan); ?>%
                            <?php echo e($data->status_jalan >= 50 ? '(baik)' : '(buruk)'); ?></td>
                    </tr>

                    <tr>
                        <th>Dimensi saluran</th>
                        <td>
                            : Panjang =
                            <?php echo e($data->dimensi_saluran_panjang_kanan != 0 ? $data->dimensi_saluran_panjang_kanan . 'm' : 'tidak ada'); ?>

                            (kanan) dan
                            <?php echo e($data->dimensi_saluran_panjang_kiri != 0 ? $data->dimensi_saluran_panjang_kiri . ' m' : 'tidak ada'); ?>

                            (kiri)<br>
                            : Lebar =
                            <?php echo e($data->dimensi_saluran_lebar_kanan != 0 ? $data->dimensi_saluran_lebar_kanan . ' m' : 'tidak ada'); ?>

                            (kanan) dan
                            <?php echo e($data->dimensi_saluran_lebar_kiri != 0 ? $data->dimensi_saluran_lebar_kiri . ' m' : 'tidak ada'); ?>

                            (kiri)<br>
                            : Kedalaman =
                            <?php echo e($data->dimensi_saluran_kedalaman_kanan != 0 ? $data->dimensi_saluran_kedalaman_kanan . ' m' : 'tidak ada'); ?>

                            (kanan) dan
                            <?php echo e($data->dimensi_saluran_kedalaman_kiri != 0 ? $data->dimensi_saluran_kedalaman_kiri . ' m' : 'tidakada'); ?>

                            (kiri)<br>
                        </td>
                    </tr>

                    <tr>
                        <th>Kondisi saluran</th>
                        <td>: <?php echo e($data->konstruksiSaluran->jenis); ?> Kondisi <?php echo e($data->status_saluran); ?>%
                            <?php echo e($data->status_saluran >= 50 ? '(baik)' : '(buruk)'); ?></td>
                    </tr>

                    <tr>
                        <th>Jenis Fasos</th>
                        <td> :
                            <?php if(count($data->fasosTable) == 0): ?>
                                Tidak ada
                            <?php else: ?>
                                <?php $__currentLoopData = $data->fasosTable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <b><?php echo e($item->jenisFasos->jenis); ?> :</b>
                                    <table class="layak fasos">
                                        <tr>
                                            <th>:Koordinat</th>
                                            <td><?php echo e($item->koordinat_fasos); ?></td>
                                        </tr>
                                        <tr>
                                            <th>:Panjang</th>
                                            <td>= <?php echo e($item->panjang); ?> m</td>
                                        </tr>
                                        <tr>
                                            <th>: Lebar</th>
                                            <td>= <?php echo e($item->lebar); ?> m</td>
                                        </tr>
                                        <tr>
                                            <th>: Luas</th>
                                            <td>= <?php echo e($item->lebar * $data->fasosTable[$loop->index]->panjang); ?> m</td>
                                        </tr>
                                    </table>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                    </tr>

                    <tr>
                        <th>Jumlah rumah</th>
                        <td>
                            <table class="layak">
                                <tr>
                                    <th>: Layak </th>
                                    <td>= <?php echo e($data->jumlah_rumah_layak); ?> Unit</td>
                                </tr>
                                <tr>
                                    <th>: Tidak Layak</th>
                                    <td>= <?php echo e($data->jumlah_rumah_tak_layak); ?> Unit</td>
                                </tr>
                                <tr>
                                    <th>: Kosong</th>
                                    <td>= <?php echo e($data->jumlah_rumah_kosong); ?> Unit</td>
                                </tr>
                            </table>
                        </td>
                    </tr>

                    <tr>
                        <th>Jenis rumah</th>
                        <td>: Developer = <?php echo e($data->jumlah_rumah_developer); ?> Unit<br>
                            : Swadaya = <?php echo e($data->jumlah_rumah_swadaya); ?> Unit
                        </td>
                    </tr>

                    <tr>
                        <th>Pos jaga</th>
                        <td>: <?php echo e($data->pos_jaga == 1 ? 'Ada' : 'Tidak Ada'); ?></td>
                    </tr>

                    <tr>
                        <th>Ruko di bagian depan</th>
                        <td>: Kanan =
                            <?php if($data->jumlah_ruko_kanan == 0): ?>
                                tidak ada
                            <?php else: ?>
                                <?php echo e($data->jumlah_ruko_kanan); ?> unit <?php echo e($data->lantai_ruko_kanan); ?> lantai
                            <?php endif; ?><br>
                            : kiri = <?php if($data->jumlah_ruko_kiri == 0): ?>
                                tidak ada
                            <?php else: ?>
                                <?php echo e($data->jumlah_ruko_kiri); ?> unit <?php echo e($data->lantai_ruko_kiri); ?> lantai
                            <?php endif; ?>
                        </td>
                    </tr>

                    <tr>
                        <th>No. IMB Pendahuluan</th>
                        <td>: <?php echo e($data->no_imb != 0 ? $data->no_imb : '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Catatan</th>
                        <td>: <?php echo e($data->catatan); ?></td>
                    </tr>

                    <tr>
                        <th>Surveyor</th>
                        <td>: <b><?php echo e($data->user->nama_lengkap); ?></b></td>
                    </tr>

                    <tr>
                        <th>Lampiran data</th>
                        <td>
                            <?php echo e(count($data->lampiranFoto) == 0 && count($data->fasosTable) == 0 ? ': -' : ':'); ?>

                        </td>
                    </tr>
                </table>
                <table width='100%' align="center">
                    
                    <?php $__currentLoopData = $data->fasosTable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->iteration % 2 == 1): ?>
                            <tr class="d-flex flex-column flex-sm-row justify-content-center">
                        <?php endif; ?>
                        <td align="center" style="padding: 10px">
                            <h3 style="text-align: center"><?php echo e($item->jenisFasos->jenis); ?></h3>
                            <img src="<?php echo e(asset('storage/' . $item->foto)); ?>" width="300px" height="200px">
                        </td>
                        <?php if($loop->iteration % 2 == 0 || $loop->iteration == count($data->fasosTable) + 1): ?>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <table width='100%' align="center">
                    
                    <?php $__currentLoopData = $data->lampiranFoto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->iteration % 2 == 1): ?>
                            <tr class="d-flex flex-column flex-sm-row justify-content-center">
                        <?php endif; ?>
                        <td align="center" style="padding: 10px">
                            <h3 style="text-align: center"><?php echo e($item->jenisLampiran->jenis); ?></h3>
                            <img src="<?php echo e(asset('storage/' . $item->foto)); ?>" width="300px" height="200px">
                        </td>
                        <?php if($loop->iteration % 2 == 0 || $loop->iteration == count($data->lampiranFoto) + 1): ?>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <div class="tombol-detail col-12 d-flex justify-content-center">
                    <?php if(auth()->user()->id == $data->user->id): ?>
                        <a href="/surveyor/data-survei/detail/edit/<?php echo e(request()->id); ?>"
                            class="text-decoration-none btn btn-warning m-2 text-white" style="border-radius: .5em;"><i
                                class="far fa-edit pe-2"></i>Edit</a>
                    <?php endif; ?>
                    <a href="/data-survei/print/<?php echo e($data->id); ?>"
                        class="text-decoration-none btn btn-primary m-2 text-white border-0"
                        style="background: #3F4FC8; border-radius: .5em;"><i class="fas fa-download pe-2"></i>Download</a>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\survey-in\resources\views/user/detail-data-survei.blade.php ENDPATH**/ ?>